---
date: 2021-05-20
title: The Four Onions
tags: Books, Publishing, Chapbook, 
start_date:
end_date:
item_link:
image: "images/4onions.jpg"
published: true
---

These poems started with food. I was writing down what I talked about most, and I talked a lot about the things I eat and don’t eat. For example, beef jerky vs. eggs. I realize now that food was the beginning because 1) my parents ran a café/diner during my adolescence and 2) I am learning about the relationship between history and the senses.

Order from [yolkless press](https://yolklesspress.com/publications/the-four-onions/) or [Art Metropole](https://artmetropole.com/shop/14636)
  
32 pages, risograph printed, May 2021.

