---
date: 2022-01-13
title: C**kie M*nster *nterpreter
tags: Amy Lam
start_date: 2019-01-01
end_date: 2020-12-01
item_link: 
image: "images/cookiemonster.png"
---

C\*\*kie M\*nster \*nterpreter is a livestream lecture-performance-performance "about" translation, cuteness and the un-human (monsterdom). Based on a true story!

A collaboration with [Oliver Husain](http://www.husain.de/). With Aliya Pabani. Sound by Matt Smith/Prince Nifty. Assistance from Monica Moraru.

Watch the archived livestream at [twitch.tv/cookiemonsterinterpreter](http://twitch.tv/cookiemonsterinterpreter)

Presented by the [11th Seoul MediaCity Biennale](https://www.mediacityseoul.kr/en/c-kie-m-nster-nterpreter), on Nov. 14, 2021.

