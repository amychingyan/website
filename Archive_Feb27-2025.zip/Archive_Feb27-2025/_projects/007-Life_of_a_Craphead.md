---
date: 2016-01-01
title: Life of a Craphead
tags: Life of a Craphead, 
start_date: 2016-01-01
end_date: 2020-01-01
item_link: http://www.lifeofacraphead.com/
image: "images/LOAC_KingEdward_2.jpg"
published: true
---
Life of a Craphead was the art collective of myself and Jon McCurley in performance, film, and conceptual art (2006-2020). Our work is archived at [lifeofacraphead.com](https://www.lifeofacraphead.com)
